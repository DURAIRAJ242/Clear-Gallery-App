# Clear Gallery

Ad-free, offline photo & video gallery for Android (Kotlin + Jetpack Compose).
No internet permission, no ads, no trackers.

## Features
- Finds all photos and videos on the phone (internal storage + SD card)
- Library (grouped by day), Albums, Favourites tabs
- Favourites (heart), also in bulk via multi-select
- Editing: filters, brightness / contrast / saturation / warmth, crop ratios, rotate / flip. Saves a copy to Pictures/Clear Gallery
- Sort: date, name, size (both directions) + grid size
- Filter: photos / videos / album
- Full-screen viewer with pinch-zoom, swipe, video player, share, details, delete (system trash)
- Light and dark themes

## Build and install on your phone
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this `ClearGallery` folder, wait for Gradle sync (needs internet once).
3. On the phone: Settings > About phone > tap Build number 7 times, then Settings > System > Developer options > turn on USB debugging.
4. Connect the phone by USB, accept the prompt, choose your phone at the top of Android Studio, press Run (green triangle).

To get an APK file to share or install: Build > Build Bundle(s) / APK(s) > Build APK(s).

## No computer? Build the APK on your phone with GitHub (free)
1. Make a free account at github.com and create a new repository (Private is fine).
2. Upload the contents of this folder (unzip first). Make sure the `.github` folder is included.
3. Open the repository's **Actions** tab > **Build APK** > wait about 5-8 minutes for the green tick.
4. Open that run, download **ClearGallery-apk** (a zip), unzip it and tap the `.apk` to install.
   Allow "Install unknown apps" for your browser/file manager when Android asks.
