package com.cleargallery.app.data

import android.net.Uri

/** One photo or video found on the device. */
data class Media(
    val id: Long,
    val uri: Uri,
    val name: String,
    val isVideo: Boolean,
    val dateMillis: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val bucketId: Long,
    val bucketName: String,
    val mimeType: String,
    val path: String,
) {
    /** Stable key used for favourites and selection. */
    val key: String get() = (if (isVideo) "v" else "i") + id
}

/** A folder/album such as Camera, Screenshots, WhatsApp Images... */
data class Album(
    val id: Long,
    val name: String,
    val count: Int,
    val cover: Media,
)
