@file:OptIn(ExperimentalMaterial3Api::class)

package com.cleargallery.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.RotateLeft
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.cleargallery.app.data.Media
import com.cleargallery.app.util.decodeForEditing
import com.cleargallery.app.util.saveToGallery
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

// ---- colour maths (Android's 4x5 matrix: R,G,B,A rows, last column is an offset in 0..255) ----

private fun satMatrix(s: Float): FloatArray = AndroidColorMatrix().apply { setSaturation(s) }.array

private fun contrastMatrix(c: Float, offset: Float = 0f): FloatArray {
    val t = (1f - c) * 128f + offset
    return floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f,
    )
}

private fun channelMatrix(r: Float, g: Float, b: Float): FloatArray = floatArrayOf(
    r, 0f, 0f, 0f, 0f,
    0f, g, 0f, 0f, 0f,
    0f, 0f, b, 0f, 0f,
    0f, 0f, 0f, 1f, 0f,
)

/** Applies [first] and then [second]. */
private fun concat(first: FloatArray, second: FloatArray): FloatArray {
    val m = AndroidColorMatrix(first)
    m.postConcat(AndroidColorMatrix(second))
    return m.array
}

private enum class Preset(val label: String, val matrix: FloatArray?) {
    Original("Original", null),
    Vivid("Vivid", concat(satMatrix(1.5f), contrastMatrix(1.08f))),
    Warm("Warm", channelMatrix(1.12f, 1.02f, 0.86f)),
    Cool("Cool", channelMatrix(0.9f, 1.0f, 1.15f)),
    Fade("Fade", contrastMatrix(0.82f, 22f)),
    Mono("Mono", satMatrix(0f)),
    Noir("Noir", concat(satMatrix(0f), contrastMatrix(1.35f))),
    Sepia(
        "Sepia",
        floatArrayOf(
            0.393f, 0.769f, 0.189f, 0f, 0f,
            0.349f, 0.686f, 0.168f, 0f, 0f,
            0.272f, 0.534f, 0.131f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        ),
    ),
}

private fun buildColorArray(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    warmth: Float,
    preset: Preset,
): FloatArray {
    var m = satMatrix(saturation)
    m = concat(m, contrastMatrix(contrast, brightness * 1.2f))
    m = concat(m, channelMatrix(1f + 0.18f * warmth, 1f + 0.03f * warmth, 1f - 0.18f * warmth))
    preset.matrix?.let { m = concat(m, it) }
    return m
}

// ---- crop ----

private enum class CropRatio(val label: String, val ratio: Float?) {
    Free("Original", null),
    Square("1:1", 1f),
    R43("4:3", 4f / 3f),
    R34("3:4", 3f / 4f),
    R169("16:9", 16f / 9f),
    R916("9:16", 9f / 16f),
}

private fun cropRect(w: Int, h: Int, ratio: Float?): Rect {
    if (ratio == null) return Rect(0, 0, w, h)
    val current = w.toFloat() / h
    return if (current > ratio) {
        val nw = (h * ratio).toInt().coerceIn(1, w)
        val x = (w - nw) / 2
        Rect(x, 0, x + nw, h)
    } else {
        val nh = (w / ratio).toInt().coerceIn(1, h)
        val y = (h - nh) / 2
        Rect(0, y, w, y + nh)
    }
}

private fun renderFinal(src: Bitmap, ratio: Float?, colors: FloatArray): Bitmap {
    val r = cropRect(src.width, src.height, ratio)
    val out = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(AndroidColorMatrix(colors))
    }
    Canvas(out).drawBitmap(src, r, Rect(0, 0, r.width(), r.height()), paint)
    return out
}

private fun Bitmap.transformed(block: Matrix.() -> Unit): Bitmap {
    val m = Matrix().apply(block)
    return Bitmap.createBitmap(this, 0, 0, width, height, m, true)
}

private fun Bitmap.scaledToMax(maxDim: Int): Bitmap {
    val scale = maxDim.toFloat() / maxOf(width, height)
    if (scale >= 1f) return this
    return Bitmap.createScaledBitmap(this, (width * scale).toInt().coerceAtLeast(1), (height * scale).toInt().coerceAtLeast(1), true)
}

private enum class EditTool(val label: String, val icon: ImageVector) {
    Filters("Filters", Icons.Rounded.AutoAwesome),
    Adjust("Adjust", Icons.Rounded.Tune),
    Crop("Crop", Icons.Rounded.Crop),
    Rotate("Rotate", Icons.Rounded.RotateRight),
}

// ---- screen ----

@Composable
fun EditorScreen(media: Media, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var base by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var warmth by remember { mutableFloatStateOf(0f) }
    var preset by remember { mutableStateOf(Preset.Original) }
    var crop by remember { mutableStateOf(CropRatio.Free) }
    var tool by remember { mutableStateOf(EditTool.Filters) }
    var saving by remember { mutableStateOf(false) }
    var confirmDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(media.uri) {
        val bmp = withContext(Dispatchers.IO) {
            runCatching { decodeForEditing(ctx, media.uri) }.getOrNull()
        }
        if (bmp == null) {
            Toast.makeText(ctx, "Couldn't open this photo", Toast.LENGTH_SHORT).show()
            onClose()
        } else {
            original = bmp
            base = bmp
        }
    }

    val colorArray = remember(brightness, contrast, saturation, warmth, preset) {
        buildColorArray(brightness, contrast, saturation, warmth, preset)
    }
    val changed = base !== original ||
        abs(brightness) > 0.5f || abs(contrast - 1f) > 0.005f || abs(saturation - 1f) > 0.005f ||
        abs(warmth) > 0.005f || preset != Preset.Original || crop != CropRatio.Free

    fun reset() {
        base = original
        brightness = 0f
        contrast = 1f
        saturation = 1f
        warmth = 0f
        preset = Preset.Original
        crop = CropRatio.Free
    }

    fun save() {
        val src = base ?: return
        saving = true
        scope.launch {
            val uri = withContext(Dispatchers.IO) {
                runCatching { saveToGallery(ctx, renderFinal(src, crop.ratio, colorArray)) }.getOrNull()
            }
            saving = false
            if (uri != null) {
                onSaved()
            } else {
                Toast.makeText(ctx, "Couldn't save the photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler {
        if (saving) return@BackHandler
        if (changed) confirmDiscard = true else onClose()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Edit photo", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = { if (changed) confirmDiscard = true else onClose() }) {
                        Icon(Icons.Rounded.Close, "Close")
                    }
                },
                actions = {
                    IconButton(onClick = ::reset, enabled = changed && !saving) {
                        Icon(Icons.Rounded.Restore, "Reset")
                    }
                    Button(
                        onClick = ::save,
                        enabled = changed && !saving && base != null,
                        modifier = Modifier.padding(end = 12.dp),
                    ) { Text("Save", fontWeight = FontWeight.SemiBold) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.surfaceContainer)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp, bottom = 6.dp),
                ) {
                    when (tool) {
                        EditTool.Filters -> {
                            val thumb = remember(base) { base?.scaledToMax(200)?.asImageBitmap() }
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(Preset.entries.toList()) { p ->
                                    val selected = preset == p
                                    Column(
                                        Modifier.clickable { preset = p },
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        val shape = RoundedCornerShape(14.dp)
                                        if (thumb != null) {
                                            Image(
                                                bitmap = thumb,
                                                contentDescription = p.label,
                                                contentScale = ContentScale.Crop,
                                                colorFilter = p.matrix?.let { ColorFilter.colorMatrix(ColorMatrix(it)) },
                                                modifier = Modifier
                                                    .size(72.dp)
                                                    .clip(shape)
                                                    .then(
                                                        if (selected) {
                                                            Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, shape)
                                                        } else {
                                                            Modifier
                                                        },
                                                    ),
                                            )
                                        } else {
                                            Box(Modifier.size(72.dp))
                                        }
                                        Text(
                                            p.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(top = 6.dp),
                                        )
                                    }
                                }
                            }
                        }

                        EditTool.Adjust -> Column(Modifier.padding(horizontal = 16.dp)) {
                            AdjustRow("Brightness", brightness, -100f..100f, brightness.roundToInt().toString()) { brightness = it }
                            AdjustRow("Contrast", contrast, 0.5f..1.5f, ((contrast - 1f) * 100).roundToInt().toString()) { contrast = it }
                            AdjustRow("Saturation", saturation, 0f..2f, ((saturation - 1f) * 100).roundToInt().toString()) { saturation = it }
                            AdjustRow("Warmth", warmth, -1f..1f, (warmth * 100).roundToInt().toString()) { warmth = it }
                        }

                        EditTool.Crop -> LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(CropRatio.entries.toList()) { c ->
                                FilterChip(
                                    selected = crop == c,
                                    onClick = { crop = c },
                                    label = { Text(c.label) },
                                )
                            }
                        }

                        EditTool.Rotate -> Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                        ) {
                            ToolButton(Icons.Rounded.RotateLeft, "Left") { base = base?.transformed { postRotate(-90f) } }
                            ToolButton(Icons.Rounded.RotateRight, "Right") { base = base?.transformed { postRotate(90f) } }
                            ToolButton(Icons.Rounded.Flip, "Flip ↔") { base = base?.transformed { postScale(-1f, 1f) } }
                            ToolButton(Icons.Rounded.Flip, "Flip ↕", iconRotation = 90f) { base = base?.transformed { postScale(1f, -1f) } }
                        }
                    }
                }
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    EditTool.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tool == t,
                            onClick = { tool = t },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = base
            if (bmp == null) {
                CircularProgressIndicator()
            } else {
                val image = remember(bmp) { bmp.asImageBitmap() }
                val ratio = crop.ratio ?: (bmp.width.toFloat() / bmp.height)
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    colorFilter = ColorFilter.colorMatrix(ColorMatrix(colorArray)),
                    modifier = Modifier
                        .aspectRatio(ratio)
                        .clip(RoundedCornerShape(14.dp)),
                )
            }
            if (saving) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center,
                ) { CircularProgressIndicator() }
            }
        }
    }

    if (confirmDiscard) {
        AlertDialog(
            onDismissRequest = { confirmDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("Your edits haven't been saved.") },
            confirmButton = { TextButton(onClick = onClose) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { confirmDiscard = false }) { Text("Keep editing") } },
        )
    }
}

@Composable
private fun AdjustRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(88.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text(
            display,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.End,
            modifier = Modifier.width(36.dp),
        )
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, iconRotation: Float = 0f, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalButton(onClick = onClick, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(56.dp)) {
            Icon(icon, label, modifier = Modifier.rotate(iconRotation))
        }
        Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 6.dp))
    }
}
