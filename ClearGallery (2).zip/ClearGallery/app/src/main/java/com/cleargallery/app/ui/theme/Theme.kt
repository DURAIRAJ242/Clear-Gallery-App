package com.cleargallery.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Heart colour for favourites. */
val FavoriteRed = Color(0xFFFF4D79)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B5FEF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE4E5FF),
    onPrimaryContainer = Color(0xFF14166B),
    secondary = Color(0xFF12A594),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3F4EE),
    onSecondaryContainer = Color(0xFF00382F),
    tertiary = FavoriteRed,
    background = Color(0xFFF6F7FC),
    onBackground = Color(0xFF14161F),
    surface = Color.White,
    onSurface = Color(0xFF14161F),
    surfaceVariant = Color(0xFFE9EBF5),
    onSurfaceVariant = Color(0xFF50556B),
    outline = Color(0xFF8A8FA8),
    outlineVariant = Color(0xFFD8DBEA),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF9FAFE),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFF1F2FA),
    surfaceContainerHighest = Color(0xFFE9EBF5),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9DA0FF),
    onPrimary = Color(0xFF0F1170),
    primaryContainer = Color(0xFF2B2F9E),
    onPrimaryContainer = Color(0xFFE0E1FF),
    secondary = Color(0xFF4FD8C4),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF0E5247),
    onSecondaryContainer = Color(0xFFD3F4EE),
    tertiary = Color(0xFFFF7D9C),
    background = Color(0xFF0D0F14),
    onBackground = Color(0xFFE6E8F2),
    surface = Color(0xFF12151C),
    onSurface = Color(0xFFE6E8F2),
    surfaceVariant = Color(0xFF232733),
    onSurfaceVariant = Color(0xFFB1B6CC),
    outline = Color(0xFF6E7391),
    outlineVariant = Color(0xFF2E3243),
    surfaceContainerLowest = Color(0xFF0A0C10),
    surfaceContainerLow = Color(0xFF12151C),
    surfaceContainer = Color(0xFF171A22),
    surfaceContainerHigh = Color(0xFF1E222C),
    surfaceContainerHighest = Color(0xFF262B37),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun GalleryTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
