package com.cleargallery.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Favourites are kept privately inside the app (SharedPreferences) — your files are never touched. */
class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)
    private val _keys = MutableStateFlow<Set<String>>(prefs.getStringSet("keys", emptySet())?.toSet() ?: emptySet())
    val keys: StateFlow<Set<String>> = _keys

    fun toggle(key: String) {
        setAll(listOf(key), key !in _keys.value)
    }

    fun setAll(keys: Collection<String>, favorite: Boolean) {
        val next: Set<String> = if (favorite) _keys.value + keys else _keys.value - keys.toSet()
        _keys.value = next
        prefs.edit().putStringSet("keys", HashSet(next)).apply()
    }
}
