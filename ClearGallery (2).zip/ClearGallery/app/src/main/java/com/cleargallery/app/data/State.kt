package com.cleargallery.app.data

enum class HomeTab { Library, Albums, Favourites }

enum class TypeFilter(val label: String) {
    All("All"),
    Photos("Photos"),
    Videos("Videos"),
}

enum class SortOption(val label: String) {
    DateNewest("Date · Newest first"),
    DateOldest("Date · Oldest first"),
    NameAZ("Name · A to Z"),
    NameZA("Name · Z to A"),
    SizeLargest("Size · Largest first"),
    SizeSmallest("Size · Smallest first");

    val byDate: Boolean get() = this == DateNewest || this == DateOldest
}

data class UiState(
    val tab: HomeTab = HomeTab.Library,
    val sort: SortOption = SortOption.DateNewest,
    val type: TypeFilter = TypeFilter.All,
    /** Album chosen in the Filter sheet (Library tab only). */
    val albumFilter: Long? = null,
    /** Album currently opened from the Albums tab. */
    val openAlbum: Long? = null,
    val columns: Int = 3,
)

data class ViewerState(val items: List<Media>, val index: Int)

sealed interface GridEntry {
    val key: String
}

data class HeaderEntry(val label: String) : GridEntry {
    override val key: String get() = "h_$label"
}

data class MediaEntry(val media: Media, val index: Int) : GridEntry {
    override val key: String get() = media.key
}

data class VisibleList(val items: List<Media>, val entries: List<GridEntry>) {
    companion object {
        val Empty = VisibleList(emptyList(), emptyList())
    }
}
