package com.cleargallery.app

import android.app.Application
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cleargallery.app.data.Album
import com.cleargallery.app.data.FavoritesStore
import com.cleargallery.app.data.GridEntry
import com.cleargallery.app.data.HeaderEntry
import com.cleargallery.app.data.HomeTab
import com.cleargallery.app.data.Media
import com.cleargallery.app.data.MediaEntry
import com.cleargallery.app.data.MediaRepository
import com.cleargallery.app.data.SortOption
import com.cleargallery.app.data.TypeFilter
import com.cleargallery.app.data.UiState
import com.cleargallery.app.data.ViewerState
import com.cleargallery.app.data.VisibleList
import com.cleargallery.app.util.dayLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val favStore = FavoritesStore(app)
    private val settings = app.getSharedPreferences("settings", 0)

    val favorites: StateFlow<Set<String>> = favStore.keys

    private val _all = MutableStateFlow<List<Media>>(emptyList())
    val all: StateFlow<List<Media>> = _all.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val ui = MutableStateFlow(
        UiState(
            sort = runCatching { SortOption.valueOf(settings.getString("sort", "") ?: "") }
                .getOrDefault(SortOption.DateNewest),
            columns = settings.getInt("columns", 3).coerceIn(3, 5),
        ),
    )

    val selected = MutableStateFlow<Set<String>>(emptySet())
    val viewer = MutableStateFlow<ViewerState?>(null)
    val editing = MutableStateFlow<Media?>(null)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val visible: StateFlow<VisibleList> = combine(_all, favorites, ui) { all, favs, state ->
        computeVisible(all, favs, state)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, VisibleList.Empty)

    val albums: StateFlow<List<Album>> = _all.map { buildAlbums(it) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- loading -------------------------------------------------------------------------

    private var loadJob: Job? = null

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            reload(delayMs = 600)
        }
    }

    init {
        val resolver = app.contentResolver
        resolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
    }

    /** (Re)scans the device. Safe to call often. */
    fun reload(delayMs: Long = 0) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (delayMs > 0) delay(delayMs)
            val list = try {
                repo.loadAll()
            } catch (e: SecurityException) {
                emptyList()
            }
            _all.value = list
            _loading.value = false
        }
    }

    // ---- favourites ----------------------------------------------------------------------

    fun toggleFavourite(media: Media) = favStore.toggle(media.key)

    fun setFavourite(items: List<Media>, favorite: Boolean) =
        favStore.setAll(items.map { it.key }, favorite)

    // ---- navigation / filters / sort -----------------------------------------------------

    fun setTab(tab: HomeTab) {
        selected.value = emptySet()
        ui.update { s ->
            when {
                tab == s.tab && tab == HomeTab.Albums -> s.copy(openAlbum = null)
                tab == HomeTab.Albums -> s.copy(tab = tab)
                else -> s.copy(tab = tab, openAlbum = null)
            }
        }
    }

    fun openAlbum(id: Long) = ui.update { it.copy(openAlbum = id) }
    fun closeAlbum() = ui.update { it.copy(openAlbum = null) }

    fun setSort(sort: SortOption) {
        ui.update { it.copy(sort = sort) }
        settings.edit().putString("sort", sort.name).apply()
    }

    fun setColumns(columns: Int) {
        ui.update { it.copy(columns = columns) }
        settings.edit().putInt("columns", columns).apply()
    }

    fun setType(type: TypeFilter) = ui.update { it.copy(type = type) }
    fun setAlbumFilter(id: Long?) = ui.update { it.copy(albumFilter = id) }
    fun resetFilters() = ui.update { it.copy(type = TypeFilter.All, albumFilter = null) }

    // ---- selection -----------------------------------------------------------------------

    fun toggleSelect(key: String) = selected.update { if (key in it) it - key else it + key }
    fun clearSelection() { selected.value = emptySet() }
    fun selectAll() { selected.value = visible.value.items.map { it.key }.toSet() }

    // ---- viewer / editor -----------------------------------------------------------------

    fun openViewer(items: List<Media>, index: Int) {
        if (items.isNotEmpty()) viewer.value = ViewerState(items, index)
    }

    fun closeViewer() { viewer.value = null }
    fun openEditor(media: Media) { editing.value = media }
    fun closeEditor() { editing.value = null }

    fun onEdited() {
        editing.value = null
        reload(delayMs = 400)
        _messages.tryEmit("Saved a copy to Pictures/Clear Gallery")
    }

    fun afterTrash() {
        selected.value = emptySet()
        viewer.value = null
        reload(delayMs = 200)
        _messages.tryEmit("Moved to trash")
    }

    // ---- helpers -------------------------------------------------------------------------

    private fun computeVisible(all: List<Media>, favs: Set<String>, s: UiState): VisibleList {
        var list: List<Media> = when (s.type) {
            TypeFilter.All -> all
            TypeFilter.Photos -> all.filter { !it.isVideo }
            TypeFilter.Videos -> all.filter { it.isVideo }
        }
        list = when (s.tab) {
            HomeTab.Favourites -> list.filter { it.key in favs }
            HomeTab.Albums ->
                if (s.openAlbum != null) list.filter { it.bucketId == s.openAlbum } else emptyList()
            HomeTab.Library ->
                if (s.albumFilter != null) list.filter { it.bucketId == s.albumFilter } else list
        }
        list = when (s.sort) {
            SortOption.DateNewest -> list.sortedByDescending { it.dateMillis }
            SortOption.DateOldest -> list.sortedBy { it.dateMillis }
            SortOption.NameAZ -> list.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
            SortOption.NameZA -> list.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.name })
            SortOption.SizeLargest -> list.sortedByDescending { it.size }
            SortOption.SizeSmallest -> list.sortedBy { it.size }
        }
        return VisibleList(list, buildEntries(list, s.sort.byDate))
    }

    private fun buildEntries(items: List<Media>, grouped: Boolean): List<GridEntry> {
        if (!grouped) return items.mapIndexed { i, m -> MediaEntry(m, i) }
        val out = ArrayList<GridEntry>(items.size + 64)
        var last: String? = null
        items.forEachIndexed { i, m ->
            val label = dayLabel(m.dateMillis)
            if (label != last) {
                out += HeaderEntry(label)
                last = label
            }
            out += MediaEntry(m, i)
        }
        return out
    }

    private fun buildAlbums(all: List<Media>): List<Album> =
        all.groupBy { it.bucketId }
            .map { (id, items) ->
                val newest = items.maxByOrNull { it.dateMillis } ?: items.first()
                Album(id = id, name = newest.bucketName, count = items.size, cover = newest)
            }
            .sortedByDescending { it.cover.dateMillis }
}
