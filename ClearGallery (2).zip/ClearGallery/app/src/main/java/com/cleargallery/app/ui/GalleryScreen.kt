@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.cleargallery.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.cleargallery.app.GalleryViewModel
import com.cleargallery.app.data.Album
import com.cleargallery.app.data.GridEntry
import com.cleargallery.app.data.HeaderEntry
import com.cleargallery.app.data.HomeTab
import com.cleargallery.app.data.Media
import com.cleargallery.app.data.MediaEntry
import com.cleargallery.app.data.SortOption
import com.cleargallery.app.data.TypeFilter
import com.cleargallery.app.data.UiState
import com.cleargallery.app.ui.theme.FavoriteRed

@Composable
fun GalleryScreen(
    vm: GalleryViewModel,
    snackbar: SnackbarHostState,
    onShare: (List<Media>) -> Unit,
    onTrash: (List<Media>) -> Unit,
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val all by vm.all.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()

    var showSort by remember { mutableStateOf(false) }
    var showFilter by remember { mutableStateOf(false) }

    val selecting = selected.isNotEmpty()
    val selectedItems = remember(selected, visible) { visible.items.filter { it.key in selected } }
    val inAlbumList = ui.tab == HomeTab.Albums && ui.openAlbum == null
    val inOpenAlbum = ui.tab == HomeTab.Albums && ui.openAlbum != null
    val filterActive = ui.type != TypeFilter.All || (ui.tab == HomeTab.Library && ui.albumFilter != null)

    BackHandler(enabled = selecting) { vm.clearSelection() }
    BackHandler(enabled = !selecting && inOpenAlbum) { vm.closeAlbum() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selecting) {
                val allFav = selectedItems.isNotEmpty() && selectedItems.all { it.key in favs }
                TopAppBar(
                    title = { Text("${selected.size} selected", style = MaterialTheme.typography.titleLarge) },
                    navigationIcon = {
                        IconButton(onClick = vm::clearSelection) { Icon(Icons.Rounded.Close, "Cancel") }
                    },
                    actions = {
                        IconButton(onClick = vm::selectAll) { Icon(Icons.Rounded.SelectAll, "Select all") }
                        IconButton(onClick = { vm.setFavourite(selectedItems, !allFav) }) {
                            Icon(
                                if (allFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                "Favourite",
                                tint = if (allFav) FavoriteRed else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        IconButton(onClick = { onShare(selectedItems) }) { Icon(Icons.Rounded.Share, "Share") }
                        IconButton(onClick = { onTrash(selectedItems) }) { Icon(Icons.Rounded.Delete, "Move to trash") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                )
            } else {
                val title = when {
                    inOpenAlbum -> albums.firstOrNull { it.id == ui.openAlbum }?.name ?: "Album"
                    inAlbumList -> "Albums"
                    ui.tab == HomeTab.Favourites -> "Favourites"
                    else -> "Gallery"
                }
                val subtitle = if (inAlbumList) {
                    "${albums.size} albums"
                } else {
                    countLabel(visible.items)
                }
                TopAppBar(
                    title = {
                        Column {
                            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (subtitle.isNotEmpty()) {
                                Text(
                                    subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        if (inOpenAlbum) {
                            IconButton(onClick = vm::closeAlbum) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                            }
                        }
                    },
                    actions = {
                        if (!inAlbumList) {
                            IconButton(onClick = { showFilter = true }) {
                                BadgedBox(badge = { if (filterActive) Badge(containerColor = MaterialTheme.colorScheme.primary) }) {
                                    Icon(Icons.Rounded.FilterList, "Filter")
                                }
                            }
                            IconButton(onClick = { showSort = true }) {
                                Icon(Icons.AutoMirrored.Rounded.Sort, "Sort")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            }
        },
        bottomBar = {
            if (!selecting) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    val items = listOf(
                        Triple(HomeTab.Library, "Library", Icons.Rounded.PhotoLibrary),
                        Triple(HomeTab.Albums, "Albums", Icons.Rounded.Folder),
                        Triple(HomeTab.Favourites, "Favourites", Icons.Rounded.Favorite),
                    )
                    items.forEach { (tab, label, icon) ->
                        NavigationBarItem(
                            selected = ui.tab == tab,
                            onClick = { vm.setTab(tab) },
                            icon = { Icon(icon, label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                loading && all.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))

                inAlbumList -> {
                    if (albums.isEmpty()) {
                        EmptyState(Icons.Rounded.Folder, "No albums yet", "Photos and videos on your phone will be grouped by folder here.")
                    } else {
                        AlbumsGrid(albums, onOpen = vm::openAlbum)
                    }
                }

                else -> Column(Modifier.fillMaxSize()) {
                    if (filterActive) {
                        ActiveFilterBar(ui, albums, onClear = vm::resetFilters)
                    }
                    if (visible.items.isEmpty()) {
                        if (ui.tab == HomeTab.Favourites && !filterActive) {
                            EmptyState(
                                Icons.Rounded.FavoriteBorder,
                                "No favourites yet",
                                "Open a photo or video and tap the heart to keep it here.",
                            )
                        } else {
                            EmptyState(
                                Icons.Rounded.PhotoLibrary,
                                if (filterActive) "Nothing matches your filter" else "No photos or videos found",
                                if (filterActive) "Try a different filter." else "Take a photo or copy some files to your phone and they will appear here.",
                            )
                        }
                    } else {
                        MediaGrid(
                            entries = visible.entries,
                            columns = ui.columns,
                            favs = favs,
                            selected = selected,
                            selecting = selecting,
                            onOpen = { index -> vm.openViewer(visible.items, index) },
                            onToggleSelect = { vm.toggleSelect(it.key) },
                        )
                    }
                }
            }
        }
    }

    if (showSort) {
        SortSheet(ui, onSort = vm::setSort, onColumns = vm::setColumns, onDismiss = { showSort = false })
    }
    if (showFilter) {
        FilterSheet(
            ui = ui,
            albums = albums,
            onType = vm::setType,
            onAlbum = vm::setAlbumFilter,
            onReset = vm::resetFilters,
            onDismiss = { showFilter = false },
        )
    }
}

private fun countLabel(items: List<Media>): String {
    if (items.isEmpty()) return ""
    val videos = items.count { it.isVideo }
    val photos = items.size - videos
    return buildList {
        if (photos > 0) add("$photos photo${if (photos == 1) "" else "s"}")
        if (videos > 0) add("$videos video${if (videos == 1) "" else "s"}")
    }.joinToString(" · ")
}

@Composable
private fun MediaGrid(
    entries: List<GridEntry>,
    columns: Int,
    favs: Set<String>,
    selected: Set<String>,
    selecting: Boolean,
    onOpen: (Int) -> Unit,
    onToggleSelect: (Media) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items(
            items = entries,
            key = { it.key },
            span = { entry -> if (entry is HeaderEntry) GridItemSpan(maxLineSpan) else GridItemSpan(1) },
            contentType = { if (it is HeaderEntry) 0 else 1 },
        ) { entry ->
            when (entry) {
                is HeaderEntry -> Text(
                    entry.label,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp),
                )

                is MediaEntry -> MediaCell(
                    media = entry.media,
                    favorite = entry.media.key in favs,
                    selected = entry.media.key in selected,
                    selecting = selecting,
                    onClick = {
                        if (selecting) onToggleSelect(entry.media) else onOpen(entry.index)
                    },
                    onLongClick = { onToggleSelect(entry.media) },
                )
            }
        }
    }
}

@Composable
private fun AlbumsGrid(albums: List<Album>, onOpen: (Long) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        items(albums, key = { it.id }) { album ->
            Column(Modifier.clickable { onOpen(album.id) }) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp)),
                ) {
                    AsyncImage(
                        model = rememberThumbRequest(album.cover, 480),
                        contentDescription = album.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f),
                    )
                }
                Text(
                    album.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp, start = 4.dp),
                )
                Text(
                    "${album.count} item${if (album.count == 1) "" else "s"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun ActiveFilterBar(ui: UiState, albums: List<Album>, onClear: () -> Unit) {
    val parts = buildList {
        if (ui.type != TypeFilter.All) add(ui.type.label)
        if (ui.tab == HomeTab.Library && ui.albumFilter != null) {
            add(albums.firstOrNull { it.id == ui.albumFilter }?.name ?: "Album")
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "Showing: ${parts.joinToString(" · ")}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        TextButton(onClick = onClear) { Text("Clear") }
    }
}

@Composable
private fun SortSheet(
    ui: UiState,
    onSort: (SortOption) -> Unit,
    onColumns: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
        ) {
            Text("Sort by", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.size(8.dp))
            SortOption.entries.forEach { option ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onSort(option)
                            onDismiss()
                        }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = ui.sort == option, onClick = {
                        onSort(option)
                        onDismiss()
                    })
                    Text(option.label, style = MaterialTheme.typography.bodyLarge)
                }
            }
            Spacer(Modifier.size(16.dp))
            Text("Grid size", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.size(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(3 to "Large", 4 to "Medium", 5 to "Small").forEach { (cols, label) ->
                    FilterChip(
                        selected = ui.columns == cols,
                        onClick = { onColumns(cols) },
                        label = { Text(label) },
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterSheet(
    ui: UiState,
    albums: List<Album>,
    onType: (TypeFilter) -> Unit,
    onAlbum: (Long?) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
        ) {
            Text("Filter", style = MaterialTheme.typography.titleLarge)

            Text(
                "Show",
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TypeFilter.entries.forEach { type ->
                    FilterChip(
                        selected = ui.type == type,
                        onClick = { onType(type) },
                        label = { Text(type.label) },
                        leadingIcon = if (ui.type == type) {
                            { Icon(Icons.Rounded.Check, null, Modifier.size(FilterChipDefaults.IconSize)) }
                        } else {
                            null
                        },
                    )
                }
            }

            if (ui.tab == HomeTab.Library) {
                Text(
                    "Album",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
                )
                FlowRow(
                    modifier = Modifier
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = ui.albumFilter == null,
                        onClick = { onAlbum(null) },
                        label = { Text("All albums") },
                    )
                    albums.forEach { album ->
                        FilterChip(
                            selected = ui.albumFilter == album.id,
                            onClick = { onAlbum(album.id) },
                            label = { Text("${album.name} (${album.count})") },
                        )
                    }
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onReset) { Text("Reset") }
                Spacer(Modifier.weight(1f))
                Button(onClick = onDismiss) { Text("Done", fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
