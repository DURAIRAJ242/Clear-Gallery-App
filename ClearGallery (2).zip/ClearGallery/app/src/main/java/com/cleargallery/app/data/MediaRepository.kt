package com.cleargallery.app.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Finds every photo and video on the device (internal storage + SD card) via MediaStore. */
class MediaRepository(private val context: Context) {

    suspend fun loadAll(): List<Media> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,                 // 0
            MediaStore.MediaColumns.DISPLAY_NAME,             // 1
            MediaStore.Files.FileColumns.MEDIA_TYPE,          // 2
            MediaStore.MediaColumns.DATE_ADDED,               // 3
            MediaStore.MediaColumns.DATE_TAKEN,               // 4
            MediaStore.MediaColumns.SIZE,                     // 5
            MediaStore.MediaColumns.WIDTH,                    // 6
            MediaStore.MediaColumns.HEIGHT,                   // 7
            MediaStore.MediaColumns.MIME_TYPE,                // 8
            MediaStore.MediaColumns.BUCKET_ID,                // 9
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,      // 10
            MediaStore.MediaColumns.RELATIVE_PATH,            // 11
            MediaStore.MediaColumns.DURATION,                 // 12
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"

        val out = ArrayList<Media>()
        context.contentResolver.query(collection, projection, selection, args, sort)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val isVideo = c.getInt(2) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val added = c.getLong(3) * 1000L
                val taken = c.getLong(4)
                val base = if (isVideo) {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                out += Media(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    name = c.getString(1) ?: "Unknown",
                    isVideo = isVideo,
                    dateMillis = if (taken > 0) taken else added,
                    size = c.getLong(5),
                    width = c.getInt(6),
                    height = c.getInt(7),
                    durationMs = c.getLong(12),
                    bucketId = c.getLong(9),
                    bucketName = c.getString(10) ?: "Other",
                    mimeType = c.getString(8) ?: if (isVideo) "video/*" else "image/*",
                    path = c.getString(11) ?: "",
                )
            }
        }
        out
    }
}
