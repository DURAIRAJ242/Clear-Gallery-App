package com.cleargallery.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cleargallery.app.data.Media
import com.cleargallery.app.ui.EditorScreen
import com.cleargallery.app.ui.GalleryScreen
import com.cleargallery.app.ui.ViewerScreen
import com.cleargallery.app.ui.theme.GalleryTheme
import com.cleargallery.app.util.shareMedia

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GalleryTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot(vm: GalleryViewModel = viewModel()) {
    val ctx = LocalContext.current

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    fun granted() = permissions.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    var hasAccess by remember { mutableStateOf(granted()) }
    var denied by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        hasAccess = granted()
        denied = !hasAccess
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        val now = granted()
        if (now != hasAccess) hasAccess = now
    }
    LaunchedEffect(hasAccess) { if (hasAccess) vm.reload() }

    if (!hasAccess) {
        PermissionScreen(
            showSettings = denied,
            onAllow = { permissionLauncher.launch(permissions) },
            onSettings = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)),
                )
            },
        )
        return
    }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    // One trash launcher shared by the grid and the viewer. Items go to the system trash
    // (restorable for 30 days) after the system asks for confirmation.
    val trashLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result -> if (result.resultCode == Activity.RESULT_OK) vm.afterTrash() }
    val requestTrash: (List<Media>) -> Unit = { items ->
        if (items.isNotEmpty()) {
            val request = MediaStore.createTrashRequest(ctx.contentResolver, items.map { it.uri }, true)
            trashLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        }
    }
    val share: (List<Media>) -> Unit = { shareMedia(ctx, it) }

    val viewer by vm.viewer.collectAsStateWithLifecycle()
    val editing by vm.editing.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize()) {
        GalleryScreen(vm, snackbar, onShare = share, onTrash = requestTrash)
        viewer?.let { ViewerScreen(vm, it, onShare = share, onTrash = requestTrash) }
        editing?.let { EditorScreen(it, onClose = vm::closeEditor, onSaved = vm::onEdited) }
    }
}

@Composable
private fun PermissionScreen(showSettings: Boolean, onAllow: () -> Unit, onSettings: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.background),
                ),
            ),
    ) {
        Column(
            Modifier
                .align(Alignment.Center)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .size(96.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.PhotoLibrary, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(48.dp))
            }
            Text("Clear Gallery", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Allow access to your photos and videos so they can be shown here.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
            )
            PrivacyNote(
                "No ads. No tracking. The app has no internet permission, so your media never leaves this phone.",
            )
            Button(onClick = onAllow, modifier = Modifier.padding(top = 8.dp)) { Text("Allow access") }
            if (showSettings) {
                TextButton(onClick = onSettings) { Text("Open app settings") }
            }
        }
    }
}

@Composable
private fun PrivacyNote(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
